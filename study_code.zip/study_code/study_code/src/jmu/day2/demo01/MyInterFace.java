package jmu.day2.demo01;

public interface MyInterFace {
    void method();
}
