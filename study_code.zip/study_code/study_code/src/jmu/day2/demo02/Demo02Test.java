package jmu.day2.demo02;

public class Demo02Test {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4};
        System.out.println(arr);


    }
}
