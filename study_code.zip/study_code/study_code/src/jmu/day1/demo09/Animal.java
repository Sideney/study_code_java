package jmu.day1.demo09;

//不能直接创建抽象类对象

public abstract class Animal {
     //抽象方法的定义
     public abstract void eat();

     public void normalMethod(){

     }
}
