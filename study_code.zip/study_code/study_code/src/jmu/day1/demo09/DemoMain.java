package jmu.day1.demo09;

public class DemoMain {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.eat();
    }
}
