package jmu.day1.demo08;

public class Demo01Phone {
    public static void main(String[] args) {
        NewPhone newPhone = new NewPhone();
        newPhone.show();
        newPhone.call();
        newPhone.send();
    }
}
