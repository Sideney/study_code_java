package jmu.day1.demo1;

public class Helloworld {
    public static void main(String[] args) {
        System.out.println("hello world!");
        String a = "abv";
        System.out.println(a.substring(0,0) + "123");

    }

}
