package jmu.day1.demo04;

/*
构造方法是专门用来创建对象的方法，当new对象时，其实就是在调用构造方法。
格式：
public 类名称（）{
      方法体（）
}
*/

public class Student {

    public Student(){
        System.out.println(1313);
    }
}
