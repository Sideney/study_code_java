package jmu.day1.demo04;

public class Demo04Stu {
    public static void main(String[] args) {
        Student student = new Student();
    }
}
