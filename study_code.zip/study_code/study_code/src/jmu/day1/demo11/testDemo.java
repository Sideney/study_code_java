package jmu.day1.demo11;

public class testDemo {
    public static void main(String[] args) {
        Animal animal = new Cat();
        animal.setName("dd");
        System.out.println(animal.getName());
        animal.call();
    }
}
