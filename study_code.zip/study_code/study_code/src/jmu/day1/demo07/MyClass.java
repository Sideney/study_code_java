package jmu.day1.demo07;

public class MyClass {

    public void method(){
        System.out.println("这是一个普通方法！");
    }

    public static void methodStatic(){
        System.out.println("这是一个静态方法！");
    }
}
