package jmu.designPatten.AbstractFactory;

public class NormalPrison extends NormalAbstractBlock {
    @Override
    public void printBlock() {
        System.out.print("& ");
    }
}
