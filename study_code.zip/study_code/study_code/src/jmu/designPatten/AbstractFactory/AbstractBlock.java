package jmu.designPatten.AbstractFactory;

public interface AbstractBlock {
    public abstract void printBlock();
}
