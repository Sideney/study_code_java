package jmu.designPatten.AbstractFactory;

public class NormalEmpty extends NormalAbstractBlock {

    @Override
    public void printBlock() {
        System.out.print("* ");
    }
}
