package jmu.designPatten.AbstractFactory;

public abstract class MagicAbstractBlock implements AbstractBlock {
    public abstract void printBlock();
}
