package jmu.designPatten.AbstractFactory;

public class MagicEmpty extends MagicAbstractBlock {

    @Override
    public void printBlock() {
        System.out.print("e ");
    }
}
