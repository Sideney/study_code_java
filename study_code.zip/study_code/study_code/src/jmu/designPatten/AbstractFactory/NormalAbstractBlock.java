package jmu.designPatten.AbstractFactory;

public abstract class NormalAbstractBlock implements AbstractBlock {
         public abstract void printBlock();
}
