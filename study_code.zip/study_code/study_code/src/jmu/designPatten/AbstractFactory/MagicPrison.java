package jmu.designPatten.AbstractFactory;

public class MagicPrison extends MagicAbstractBlock{
    @Override
    public void printBlock() {
        System.out.print("p ");
    }
}
