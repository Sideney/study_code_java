package jmu.designPatten.AbstractFactory;

public class MagicPark extends MagicAbstractBlock{
    @Override
    public void printBlock() {
        System.out.print("g ");
    }
}
