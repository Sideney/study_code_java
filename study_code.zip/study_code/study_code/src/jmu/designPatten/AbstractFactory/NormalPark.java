package jmu.designPatten.AbstractFactory;

public class NormalPark extends NormalAbstractBlock{
    @Override
    public void printBlock() {
        System.out.print("# ");
    }
}
