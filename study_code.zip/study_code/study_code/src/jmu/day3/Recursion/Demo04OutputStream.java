package jmu.day3.Recursion;
/*
* 字节输出流
* java.io.OutputStream:此抽象类是表示输出字节流的所有类的超类
* 文件字节输出流
* java.io.FileOutputStream extends java.io.OutputStream
* 作用：将字节写入文件中
* 构造方法：
*       FileOutputStream(String name)
*       FileOutputStream(File file)
*       参数：都是目的地
* 构造方法作用：
*       1.创建一个对象
*       2.会根据构造方法中传递的路径，创建一个空的文件
*       3.会把FileOutputStream对象指向该路径。
*
*写入数据的原理（内存->硬盘）：
* java程序->jvm->os->os调用写数据的方法->将数据写入文件中.
* */

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Demo04OutputStream {
    public static void main(String[] args) throws IOException {
//        FileOutputStream outputStream = new FileOutputStream("F:\\test\\test1\\1.txt");
//        outputStream.write(90);
//        outputStream.close();

        FileOutputStream o1 = new FileOutputStream("F:\\test\\test1\\1.txt",true);
        o1.write(96);
        byte[] bytes = "刘伟".getBytes();
        o1.write(bytes);
        o1.close();

    }
}
