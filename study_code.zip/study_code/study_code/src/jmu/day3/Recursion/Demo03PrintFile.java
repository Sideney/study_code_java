package jmu.day3.Recursion;

import java.io.File;
import java.io.FileFilter;


public class Demo03PrintFile {
    public static void main(String[] args) {
        File file = new File("F:\\test");
        getAllFile(file);
    }

    private static void getAllFile(File file) {
//        File[] files = file.listFiles(new FileFilter() {
//            @Override
//            public boolean accept(File pathname) {
//                //过滤规则
//                if(pathname.isDirectory())
//                    return true;
//                return pathname.getName().toLowerCase().endsWith("1.txt");
//
//            }
//        });
        File[] files = file.listFiles(pathname->pathname.isDirectory()||pathname.getName().toLowerCase().endsWith("1.txt"));
        for (File f:files
             ) {
            if(f.isDirectory()){
                getAllFile(f);
            }
            System.out.println(f);
        }
    }
}
