package jmu.day3.Recursion;

import java.io.File;

public class Demo02PrintFile {
    public static void main(String[] args) {
        File file = new File("F:\\test");
        getAllFile(file);
    }

    private static void getAllFile(File file) {
        File[] files = file.listFiles(new Demo02Filter());
        for (File f:files
             ) {
            if(f.isDirectory()){
                getAllFile(f);
            }
            System.out.println(f);
        }
    }
}
