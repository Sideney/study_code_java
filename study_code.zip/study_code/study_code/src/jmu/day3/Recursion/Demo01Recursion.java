package jmu.day3.Recursion;

public class Demo01Recursion {
    public static void main(String[] args) {
        int s = sum(5);
        System.out.println(s);
    }

    private static int sum(int n) {
        if(n==1){
            return 1;
        }
        return n * sum(n-1);
    }
}
