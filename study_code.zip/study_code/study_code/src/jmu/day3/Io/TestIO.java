package jmu.day3.Io;

import java.io.File;
import java.io.IOException;

public class TestIO {
    public static void main(String[] args) throws IOException {
        //show01();
        show02();
    }


    /*
    * public boolean mkdir() : 创建单级文件夹
    * public boolean mkdirs() : 创建单级多级文件夹都可以
    * */
    private static void show02() {
        File f1 = new File("study_code");
        f1.mkdir();

        File f2 = new File("study_code\\test_create_dics\\12");
        f2.mkdirs();

        String[] list = f1.list();
        for (String s : list) {
            System.out.println(s);
        }
        f2.delete();
    }

    private static void show01() throws IOException {
        File f1 = new File("D:\\workspace\\study_code\\study_code\\src\\jmu\\day3\\Io\\1.txt");
        System.out.println(f1.createNewFile());

        File f2 = new File("study_code\\2.txt");
        System.out.println(f2.createNewFile());
    }
}
