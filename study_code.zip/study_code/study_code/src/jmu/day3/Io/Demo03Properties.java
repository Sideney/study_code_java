package jmu.day3.Io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

public class Demo03Properties {
    public static void main(String[] args) throws IOException {
        show01();
    }

    private static void show01() throws IOException {
        Properties properties = new Properties();
//        properties.setProperty("1","1");
//        properties.setProperty("2","2");
//        properties.setProperty("3","3");
//        properties.setProperty("4","4");

        Set<String> names = properties.stringPropertyNames();


//        properties.store(new FileWriter("study_code\\2.txt"),"");
         properties.load(new FileReader("study_code\\2.txt"));
         properties.list(System.out);
    }
}
