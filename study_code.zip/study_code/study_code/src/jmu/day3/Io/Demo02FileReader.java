package jmu.day3.Io;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Demo02FileReader {
    public static void main(String[] args) throws IOException {
        FileReader reader = new FileReader("study_code\\2.txt");
        int len;
        char[] cs = new char[6];
        while((len = reader.read(cs))!=-1){
        System.out.println(cs);
                        }
        FileWriter writer = new FileWriter("study_code\\3.txt");
        writer.write(cs,0,2);
        writer.close();
        reader.close();
    }
}
