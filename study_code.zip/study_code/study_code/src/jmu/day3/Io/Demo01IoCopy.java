package jmu.day3.Io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Demo01IoCopy {
    public static void main(String[] args) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream("F:\\test\\test3\\2.png");
        FileInputStream fileInputStream = new FileInputStream("F:\\test\\test1\\1.png");
        byte[] bytes = new byte[1024];
        int len = 0;
        while((len = fileInputStream.read(bytes))!=-1){
            fileOutputStream.write(bytes);
        }
        fileOutputStream.close();
        fileInputStream.close();
    }
}
